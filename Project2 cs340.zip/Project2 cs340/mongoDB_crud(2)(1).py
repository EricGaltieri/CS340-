from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    
    def __init__(self, username = None, password = None):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@nv-desktop-services.apporto.com:30111' % (username, password))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

        
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            try:
                self.database.animals.insert_one(data)  # data should be dictionary  
                return True
            
            except Exception as exception:
                print(Exception)
                return False 
        
        else:
            raise Exception("Nothing to save, because data parameter is empty")
         
        
# Create method to implement the R in CRUD.
    def read(self, query=None):
        if query is not None:
            try: 
                data = self.database.animals.find(query)
                #for document in data:
                    #print(document)
                    
            except Exception as exception:
                print(Exception)
                
        else: 
            data = self.database.animals.query({}) #if the query is blank
           
        return data


# Create method to implement the U in CRUD.
    def update(self, query, updated_info):
        if query is not None: 
            try:
                result = self.database.animals.update_many(query, updated_info)
            except Exception as exception:
                print(Exception)
                
        else: 
            result = self.database.animals.query({}) #if the query is blank
            
        return result.modified_count #Show how many were updated 
    
    
# Create method to implement the D in CRUD.
    def delete(self, query):
        if query is not None: 
            try:
                result = self.database.animals.delete_many(query) #remove all
            except Exception as exception:
                print(Exception)
                
        else: 
            result = self.database.animals.query({}) #if the query is blank
        
        return result.deleted_count #Show how many were deleted 
    